# gtzan_tempo_beat
Tempo and beat annotations for GTZAN Genre dataset
